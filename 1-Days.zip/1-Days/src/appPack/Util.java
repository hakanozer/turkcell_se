package appPack;

public class Util {
	
	
	// no paramter no return
	public void fncNoParameter() {
		System.out.println("fncNoParameter call");
	}
	
	
	// no return
	public void fncParameter( int a, int b ) {
		int sum = a + b;
		System.out.println("Sum : " + sum);
	}
	
	
	// return parameter
	/**
	 *  This function numbers <b>minus</b>
	 * @param a (int)
	 * @param b (int)
	 * @return (int)
	 */
	public int fncReturn( int a, int b ) {
		int minus = a - b;
		return minus;
	}

	
}
