package appPack;

public class MainApp {
	

	// main fnc create
	public static void main(String[] args) {
		
		System.out.println("Hello Java");
		
		// Variable
		// String
		String name_1 = "Ali";
		String name_2 = "02Ali";
		String name_3 = "34";
		System.out.println(name_1 + " " + name_2);
		System.out.println(name_2.length());
		name_3 = "Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960'larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur."; 
		
		String name = "Mehmet";
		String adi = "Mehmet";
		
		
		// int
		int num1 = 50;
		int num2 = 100;
		int sum = num1 + num2;
		System.out.println("Sum : " + sum);
		
		
		// long
		long num4 = 9123812381293182331L;
		
		// byte
		byte num5 = 127;
		
		
		// double
		double num3 = 100.7676;
		System.out.println("num3 : " + num3);
		
		// float
		float f1 = 100.54F;
		
		// boolean
		boolean statu1 = false;
		
		// char
		char c1 = '?';
		
	}
	

}
