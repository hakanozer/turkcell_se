package appPack;

public class TypeCasting {
	
	public static void main(String[] args) {
		
		// String to int
		String s1 = "39";
		int cs1 = Integer.parseInt(s1);
		int sum = cs1 + 40;
		String sSum = 50 + " Toplam";
		System.out.println(sum);
		
		// String to boolean
		String s2 = "true";
		boolean cs2 = Boolean.parseBoolean(s2);
		System.out.println(cs2);
		
		
		// double to int
		double db1 = 10012312.57;
		int cdb1 = (int) db1;
		System.out.println(cdb1);
		
		
		char c1 = '9';
		int cc1 =  Integer.parseInt(""+c1);
		System.out.println(cc1);
		
	}

}
