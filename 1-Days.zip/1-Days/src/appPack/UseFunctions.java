package appPack;

public class UseFunctions {

	public static void main(String[] args) {
		
		Util ut = new Util();
		
		// no Parameter call
		ut.fncNoParameter();

		// no return
		ut.fncParameter(40, 60);
		ut.fncParameter(5, 77);
		ut.fncParameter(7, 8988);
		
		// return fnc call
		int minus = ut.fncReturn(199, 44);
		if ( ut.fncReturn(199, 44) > 100 ) {
			System.out.println("Yüzden büyük");
		}
		System.out.println("Minus : " + minus);
		
		

	}

}
