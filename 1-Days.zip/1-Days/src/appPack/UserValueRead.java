package appPack;

import java.util.Scanner;

public class UserValueRead {

	public static void main(String[] args) {
		
		
		Scanner read = new Scanner(System.in);
		System.out.println("Adınızı giriniz !");
		String name = read.nextLine();
		System.out.println("Pull Data : " + name);
		
		
		System.out.println("Yaşınızı giriniz !");
		int age = read.nextInt();
		System.out.println("Age : " + age);
		

	}

}
