package appPack;

public class Dashboard {

	public static void main(String[] args) {
		System.out.println("Hello Dashboard");
	}

}
