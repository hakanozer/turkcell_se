package appPack;

public class ControlLoop {

	public static void main(String[] args) {
		
		
		// array
		String[] arr = { "Ali", "Mehmet", "Ahmet", "Zehra", "Zeki" };
		//arr[0] = "Ayşe";
		System.out.println(arr);
		System.out.println( arr[0] );
		System.out.println( arr.length );
		
		
		for( int i = 0; i < arr.length; i++ ) {
			String item = arr[i];
			System.out.println(item);
		}
		
		
		
		for (int i = 0; i < 10000; i++) {
			if (i == 5) {
				continue;
			}
			
			System.out.println("for i : " + i);
			
			if (i == 10) {
				break; // for'u bitir
			}
		}
		
		
		/*
		for (;;) {
			System.out.println("item call");
		}
		*/
		
		for (String item : arr) {
			System.out.println("item : " + item);
		}
		
		
		// if Control
		// == 
		int a = 10;
		int b = 11;
		int c = 12;
		boolean abStatu = a == b;
		if( abStatu ) {
			System.out.println("a = b");
			System.out.println("1");
			System.out.println("Message");
		}else {
			System.out.println("a != b");
		}
		
		
		if (abStatu)
			System.out.println("{ a = b ");
		else
			System.out.println("{ a != b");
		
		
		// logic gates
		// &&, ||
		if ( a > 11 || b > 12 || c > 11 ) {
			System.out.println("if Success");
		}
		
		if ( a > 9 && b > 10 && c > 11 ) {
			System.out.println("if Success");
		}
		
		if ( a > 11 && b > 12 || c > 11 ) {
			System.out.println("if Success");
		}
		
		

	}

}
