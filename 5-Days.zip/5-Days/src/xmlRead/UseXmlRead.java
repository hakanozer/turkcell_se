package xmlRead;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;

public class UseXmlRead {

	public static void main(String[] args) {
		UseXmlRead read = new UseXmlRead();
		//read.xmlRead();
		Timer timer = new Timer();
		timer.schedule(read.task, 0, 5000);
	}
	
	
	TimerTask task = new TimerTask() {
		@Override
		public void run() {
			xmlRead();
		}
	};
	
	
	public void xmlRead() {
		try {
			long start = System.currentTimeMillis();
			String date = new Date().toGMTString();
			System.out.println("============"+date+"============");
			String url = "https://www.tcmb.gov.tr/kurlar/today.xml";
			String data = Jsoup.connect(url).timeout(30000).get().toString();
			Document doc = Jsoup.parse(data, "", Parser.xmlParser());
			Elements elements = doc.getElementsByTag("Currency");
			for( Element item : elements ) {
				String Isim = item.getElementsByTag("Isim").text();
				String ForexBuying = item.getElementsByTag("ForexBuying").text();
				String ForexSelling = item.getElementsByTag("ForexSelling").text();
				System.out.println(Isim + " " + ForexBuying +" "+ ForexSelling );
			}
			long end = System.currentTimeMillis();
			long between = end - start;
			System.out.println("========================");
			System.out.println("between : "+ between);
		} catch (Exception e) {
			System.err.println("xml read error : " + e);
		}
	}
	

}
