package appPack;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class MainApp {
	
	File file = new File("datas/sample.txt");

	public static void main(String[] args) {
		MainApp app = new MainApp();
		
		//app.fileCreate();
		//app.fileInDataWrite("Error Message");
		try {
			int a = 1;
			int b = 0;
			int c = a / b;
		} catch (Exception e) {
			app.fileInDataWrite( e.toString() );
		}
		
		try {
			String age = "40a";
			int a = Integer.parseInt(age);
		} catch (Exception e) {
			app.fileInDataWrite( e.toString() );
		}
		
		// file delete
		//app.fileDelete();
		
		app.fileRead();
		
	}
	
	
	public void fileCreate() {
		// File Create
		try {
			file.createNewFile();
		} catch (Exception e) {
			System.err.println("File Create Error : " + e);
		}
	}
	
	
	
	// file in data write 
	public void fileInDataWrite( String data ) {
		try {
			FileWriter write = new FileWriter(file, true);
			write.append(data + System.lineSeparator());
			write.close();
		} catch (Exception e) {
			System.err.println("write error : " + e);
		}
	}
	

	// file delete
	public void fileDelete() {
		try {
			file.delete();
		} catch (Exception e) {
			System.err.println("file delete error : " + e);
		}
	}
	
	
	public void fileRead() {
		try {
			Scanner read = new Scanner(file);
			while( read.hasNextLine() ) {
				String item = read.nextLine();
				System.out.println(item);
			}
		} catch (Exception e) {
			System.err.println("Read Error : " + e );
		}
	}
	
	
	
}
