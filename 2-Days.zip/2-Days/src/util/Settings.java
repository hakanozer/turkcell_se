package util;

import appPack.Actions;

public class Settings {
	
	protected String name = "Ali Bilmem";
	
	public void read() {
		String data = Actions.appName;
		System.out.println(data);
	}

}
