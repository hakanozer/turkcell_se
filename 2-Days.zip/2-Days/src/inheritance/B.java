package inheritance;

public class B extends A {
	
	@Override
	public void write() {
		String n = fncName("Ali");
		System.out.println(n);
		number = 50;
		// age = 40;
		System.out.println(age);
		System.out.println("write B");
	}

	public int sum (int a, int b) {
		return a + b;
	}
	
	
	
}
