package inheritance;

public class C extends A {
	
	@Override
	public void write() {
		System.out.println("write C");
	}

}
