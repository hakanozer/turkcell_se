package inheritance;

public class A {
	
	public A() {
		System.out.println("A Class Call");
	}

	public int number = 30;
	public final int age = 39; 
	
	public void write () {
		System.out.println("write A");
	}
	
	final public String fncName ( String name ) {
		return "Name : " + name;
	}
	
	
}
