package appPack;

public class Actions {
	
	public static String appName = "Action";
	
	private boolean statu = false;
	
	String dt = "";
	
	public Actions() {
		System.out.println("Actions call " + appName);
	}
	
	public Actions(String data) {
		dt = data;
		System.out.println("Actions call : " + data);
	}
	
	public Actions( int i ) {
		age = i;
	}
	
	
	 int age = 40;
	 
	 public void call() {
		 System.out.println("fnc Call " + dt);
	 }
	 
	 
	 public void sum() {
		 int sm = age * 2;
		 System.out.println("Sum : " + sm);
	 }

}
