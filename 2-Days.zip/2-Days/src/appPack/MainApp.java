package appPack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import inheritance.A;
import inheritance.B;
import inheritance.C;
import util.Settings;

public class MainApp {

	public static void main(String[] args) {
		
		
		
		// nesne -> object
		// new
		Actions[] arr = { new Actions(), new Actions() };
		Actions obj = new Actions();
		System.out.println(obj.age);
		obj.call();
		String name = "";
		
		
		//Actions ac1 = null;
		//ac1.call();
		
		Actions ac2 = new Actions("Java SE");
		ac2.call();
		
		
		
		Actions acx = new Actions();
		acx.sum();
		
		Actions acy = new Actions(10);
		acy.sum();
		
		Settings st = new Settings();
		
		
		A a = new A();
		B b = new B();
		C c = new C();
		
		//a.write();
		//b.write();
		//c.write();

		call(a);
		call(b);
		call(c);
		
		List<String> ls = new ArrayList<>();
		A ab = new B();
		
	}
	
	
	public static void call( A a ) {
		if ( a instanceof B ) {
			B obj = (B) a;
			int i = obj.sum(40, 60);
			System.out.println("Sum : " + i);
		}
		a.write();
	}
	

}
