package usingArrayList;

import java.util.ArrayList;
import java.util.HashMap;

public class MainList {

	public static void main(String[] args) {
		
		
		// ArrayList
		ArrayList<String> ls = new ArrayList<>();
		
		// item add
		ls.add("İstanbul");
		ls.add("Bursa");
		ls.add("Adana");
		ls.add("Ankara");
		ls.add(1, "Gaziantep");
		ls.add(1, "Samsun");
		
		// ArrayList Size
		System.out.println("Size : " + ls.size());
		
		// item get
		System.out.println(ls.get(1));
		
		// item delete
		ls.remove(1);
		
		// all items 
		System.out.println(ls);
		
		
		// all item single write
		for (String item : ls) {
			System.out.println("item : " + item);
		}
		
		

	}

}
