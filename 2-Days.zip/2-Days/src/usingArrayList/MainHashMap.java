package usingArrayList;

import java.util.ArrayList;
import java.util.HashMap;

public class MainHashMap {

	public static void main(String[] args) {
		
		// HashMap
		HashMap<String, String> hm = new HashMap<>();
		
		// item add
		hm.put("name", "Hasan");
		hm.put("surname", "Bilmem");
		hm.put("age", "40");
		hm.put("name", "Ali");
		
		// item all sout
		System.out.println(hm);
		
		// single item
		String name = hm.get("name");
		System.out.println(name);
		
		
		// remove item
		hm.remove("name");
		
		
		System.out.println(hm);
		
		// ArrayList in HashMap
		ArrayList<HashMap<String, String>> ls = new ArrayList<>();
		
		for (int i = 0; i < 5; i++) {
			HashMap<String, String> hmx = new HashMap<>();
			hmx.put("name", "Ali " + i);
			hmx.put("surname", "Bilmem " + i);
			hmx.put("age", ""+i);
			ls.add(hmx);
		}
		
		System.out.println(ls);
		
		for ( HashMap<String, String> item : ls ) {
			String n = item.get("name");
			String s = item.get("surname");
			String a = item.get("age");
			System.out.println(n + " " + s + " " + a);
		}
		
		
	}

	
	
	
	
	
}
