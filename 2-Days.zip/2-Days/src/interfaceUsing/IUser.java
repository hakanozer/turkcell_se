package interfaceUsing;

public interface IUser {

	int number = 40;
	
	public boolean userControl( String id );
	public String userImage( String id );
	
}
