package interfaceUsing;

public interface IProductUser {

	public String[] allProduct();
	
}
