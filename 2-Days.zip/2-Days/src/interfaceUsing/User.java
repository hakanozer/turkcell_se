package interfaceUsing;

public class User implements IUser, IProductUser {

	@Override
	public boolean userControl(String id) {
		// number = 50;
		System.out.println("Number : " + number);
		if( id.equals("10") ) {
			return true;
		}
		return false;
	}

	
	@Override
	public String[] allProduct() {
		String[] arr = { "Antalya", "Bodrum", "Kilyos", "Çeşme", "Datça" };
		return arr;
	}


	@Override
	public String userImage(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
