
package UsingThread;


public class MainAppThread implements Runnable {

    @Override
    public void run() {
        for(;;) {
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
            }
            System.out.println("Thread For Call");
        }
    }
    
    
    
}
