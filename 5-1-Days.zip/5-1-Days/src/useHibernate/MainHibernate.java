
package useHibernate;

import java.util.List;
import model.Product;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class MainHibernate {
    
    SessionFactory sf = NewHibernateUtil.getSessionFactory();
    
    public static void main(String[] args) {
        
        MainHibernate mn = new MainHibernate();
        // databese product insert
        //mn.proInsert();
        //mn.allProduct();
        mn.deleteItem(6);
    }
    
    
    public void proInsert() {
        
        Session sesi = sf.openSession();
        Transaction tr = sesi.beginTransaction();
        
        Product pr = new Product();
        pr.setBarcode("123123121");
        pr.setTitle("Hibernate product");
        pr.setStoc(10);
        pr.setPrice(100.5);
        
        sesi.save(pr);
        tr.commit();
        
    }
    
    
    public void allProduct() {
        Session sesi = sf.openSession();
        List<Product> ls = sesi.createQuery("from Product").list();
        for (Product item : ls) {
            System.out.println(item.getTitle());
        }
        sesi.close();
        sf.close();
    }
    
    
    public void deleteItem( int pid ) {
        
        Session sesi = sf.openSession();
        Transaction tr = sesi.beginTransaction();
        
        Product pr = (Product) sesi.load(Product.class, pid);
        // delete
        sesi.delete(pr);
        tr.commit();
        
        sesi.close();
        sf.close();
        
    }
    
    
}
