
package appPack;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import props.User;

public class Model {
    
    static User us = new User();
    
    
    public boolean userLogin( String mail, String pass ) {
        boolean statu = false;
        try {
            DB db = new DB();
            String query = "select * from INFORMATION_SCHEMA.user where mail = ? and pass = ?";
            PreparedStatement pre = db.connect(query);
            pre.setString(1, mail);
            pre.setString(2, pass);
            ResultSet rs = pre.executeQuery();
            statu = rs.next();
            if (statu) {
                us.setUid(rs.getInt("uid"));
                us.setName(rs.getString("name"));
                us.setMail(rs.getString("mail"));
            }
            db.close();
        } catch (Exception e) {
            System.err.println("Login Error : " + e);
        }
        return statu;
    }
    
    
}
