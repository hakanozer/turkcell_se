
package appPack;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import props.User;

public class Model {
    
    static User us = new User();
    
    
    public boolean userLogin( String mail, String pass ) {
        boolean statu = false;
        try {
            DB db = new DB();
            String query = "select * from INFORMATION_SCHEMA.user where mail = ? and pass = ?";
            PreparedStatement pre = db.connect(query);
            pre.setString(1, mail);
            pre.setString(2, pass);
            ResultSet rs = pre.executeQuery();
            statu = rs.next();
            if (statu) {
                us.setUid(rs.getInt("uid"));
                us.setName(rs.getString("name"));
                us.setMail(rs.getString("mail"));
            }
            db.close();
        } catch (Exception e) {
            System.err.println("Login Error : " + e);
        }
        return statu;
    }
    
    
    
    // product insert
    public int productInsert( String title, String barcode, String stoc, String price ) {
        
        int rowCount = 0;
        try {
            DB db = new DB();
            String query = "insert into INFORMATION_SCHEMA.product values ( null, ?, ?, ?, ? )  ";
            PreparedStatement pre = db.connect(query);
            pre.setString(1, title);
            pre.setString(2, barcode);
            pre.setInt(3, Integer.parseInt(stoc));
            pre.setDouble(4, Double.parseDouble(price));
            rowCount = pre.executeUpdate();
            db.close();
        } catch (Exception e) {
            System.err.println("Insert Error : " + e);
            JOptionPane.showMessageDialog(null, "Stok(30) not empty, price(10.5) not empty");
        }
        return rowCount;
        
    }
    
    
    
    // all Product Result genarator tableModel
    public DefaultTableModel allProduct () {
        DefaultTableModel dtm = new DefaultTableModel();
        // add column
        dtm.addColumn("ID");
        dtm.addColumn("Title");
        dtm.addColumn("Barcode");
        dtm.addColumn("Stock");
        dtm.addColumn("Price");
        try {
            DB db = new DB();
            String query = "select * from INFORMATION_SCHEMA.product";
            PreparedStatement pre = db.connect(query);
            ResultSet rs = pre.executeQuery();
            while(rs.next()) {
                // generator row
                int pid = rs.getInt("pid");
                String title = rs.getString("title");
                String barcode  = rs.getString("barcode");
                int stoc = rs.getInt("stoc");
                double price = rs.getDouble("price");
                Object[] row = { pid, title, barcode, stoc, price };
                dtm.addRow(row);
            }
            db.close();
        } catch (Exception e) {
            System.err.println("allProduct Error : " + e);
        }
        return dtm;
    }
    
    
}
