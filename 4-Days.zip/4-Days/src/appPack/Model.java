
package appPack;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Model {
    
    
    public boolean userLogin( String mail, String pass ) {
        boolean statu = false;
        try {
            DB db = new DB();
            String query = "select * from INFORMATION_SCHEMA.user where mail = ? and pass = ?";
            PreparedStatement pre = db.connect(query);
            pre.setString(1, mail);
            pre.setString(2, pass);
            ResultSet rs = pre.executeQuery();
            statu = rs.next();
            db.close();
        } catch (Exception e) {
            System.err.println("Login Error : " + e);
        }
        return statu;
    }
    
    
}
