
package appPack;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class DB {

    private final String driver = "org.h2.Driver";
    private String url = "";
    private final String user = "sa";
    private final String pass = "";
    
    private Connection conn = null;
    private PreparedStatement pr = null;
    
   
    
    
    public PreparedStatement connect( String query ) {
        try {
            File file = new File("database/proje");
            url = "jdbc:h2:"+file.getAbsolutePath();
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, pass);
            pr = conn.prepareStatement(query);
            System.out.println("Connection Success");
        } catch (Exception e) {
            System.err.println("Connect Error : " + e);
        }
        return pr;
    }
    
    
    
    public void close() {
        try {
            pr.close();
            conn.close();
        } catch (Exception e) {
        }
    }
    
    
}
